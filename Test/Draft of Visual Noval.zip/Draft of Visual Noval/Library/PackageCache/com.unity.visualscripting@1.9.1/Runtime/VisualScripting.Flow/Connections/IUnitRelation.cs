namespace Unity.VisualScripting
{
    public interface IUnitRelation : IConnection<IUnitPort, IUnitPort> { }
}
