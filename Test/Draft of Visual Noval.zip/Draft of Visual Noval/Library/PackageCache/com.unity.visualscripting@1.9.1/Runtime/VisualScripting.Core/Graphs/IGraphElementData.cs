namespace Unity.VisualScripting
{
    public interface IGraphElementData { }
}
