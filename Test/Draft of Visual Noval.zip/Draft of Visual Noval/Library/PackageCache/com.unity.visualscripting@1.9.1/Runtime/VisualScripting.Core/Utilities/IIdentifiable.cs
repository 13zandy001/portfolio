using System;

namespace Unity.VisualScripting
{
    public interface IIdentifiable
    {
        Guid guid { get; }
    }
}
