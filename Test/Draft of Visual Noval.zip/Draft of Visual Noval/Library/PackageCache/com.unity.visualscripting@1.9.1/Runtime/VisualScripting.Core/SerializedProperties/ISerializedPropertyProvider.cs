namespace Unity.VisualScripting
{
    public interface ISerializedPropertyProvider
    {
        object item { get; set; }
    }
}
