namespace Unity.VisualScripting
{
    public interface IInspectableAttribute
    {
        int order { get; }
    }
}
