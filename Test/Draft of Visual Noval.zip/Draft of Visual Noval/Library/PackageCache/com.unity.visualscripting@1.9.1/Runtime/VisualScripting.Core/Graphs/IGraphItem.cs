namespace Unity.VisualScripting
{
    public interface IGraphItem
    {
        IGraph graph { get; }
    }
}
