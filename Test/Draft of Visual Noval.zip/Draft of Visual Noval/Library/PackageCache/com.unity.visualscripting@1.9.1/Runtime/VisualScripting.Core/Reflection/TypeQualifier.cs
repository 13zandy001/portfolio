namespace Unity.VisualScripting
{
    public enum TypeQualifier
    {
        Name,
        Namespace,
        GlobalNamespace
    }
}
